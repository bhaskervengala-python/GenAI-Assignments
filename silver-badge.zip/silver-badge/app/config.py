import os
from pydantic import BaseModel
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Settings(BaseModel):
    """
    Central configuration for Smart Study Buddy.
    """

    # OpenAI / LLM settings
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    MODEL_NAME: str = os.getenv("MODEL_NAME", "gpt-4.1-mini")

    # Database
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "sqlite:///./data/study_buddy.db",
    )

    # App settings
    APP_NAME: str = os.getenv("APP_NAME", "Smart Study Buddy")
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    # File storage
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", "./uploads")
    MAX_UPLOAD_SIZE_MB: int = int(os.getenv("MAX_UPLOAD_SIZE_MB", "25"))

    # Learning engine tuning
    DEFAULT_QUIZ_QUESTIONS: int = int(os.getenv("DEFAULT_QUIZ_QUESTIONS", "5"))
    MAX_QUIZ_QUESTIONS: int = int(os.getenv("MAX_QUIZ_QUESTIONS", "20"))

    # Spaced repetition tuning
    BASE_REVIEW_INTERVAL: int = int(os.getenv("BASE_REVIEW_INTERVAL", "1"))
    MAX_REVIEW_INTERVAL: int = int(os.getenv("MAX_REVIEW_INTERVAL", "64"))


# Singleton settings object
settings = Settings()