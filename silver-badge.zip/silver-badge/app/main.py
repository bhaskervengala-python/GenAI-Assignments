from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app.api import upload, quiz, explain, schedule

# Create database tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(
    title="Smart Study Buddy API",
    description=(
        "AI-powered tutoring assistant that can analyze study materials, "
        "generate quizzes, explain concepts, and create adaptive study schedules."
    ),
    version="1.0.0",
)

# Enable CORS (adjust allow_origins for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API routers
app.include_router(upload.router, prefix="/api", tags=["Upload"])
app.include_router(quiz.router, prefix="/api", tags=["Quiz"])
app.include_router(explain.router, prefix="/api", tags=["Explain"])
app.include_router(schedule.router, prefix="/api", tags=["Schedule"])


@app.get("/")
def root():
    """
    Root endpoint.
    """
    return {
        "message": "Welcome to Smart Study Buddy 🎓",
        "version": "1.0.0",
        "docs_url": "/docs",
        "health_check": "/health",
    }


@app.get("/health")
def health_check():
    """
    Health check endpoint.
    """
    return {
        "status": "healthy",
        "service": "smart-study-buddy",
    }