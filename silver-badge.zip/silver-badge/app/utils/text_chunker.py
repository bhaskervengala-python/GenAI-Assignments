from typing import List


def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
    """
    Splits large text into overlapping chunks for LLM processing.

    Args:
        text (str): Input text to split
        chunk_size (int): Maximum size of each chunk
        overlap (int): Number of overlapping characters between chunks

    Returns:
        List[str]: List of text chunks
    """

    if not text or not text.strip():
        return []

    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than 0")

    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    chunks: List[str] = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = start + chunk_size

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Move start forward with overlap
        start += chunk_size - overlap

    return chunks


def chunk_by_paragraph(text: str, max_chunk_size: int = 3000) -> List[str]:
    """
    Splits text by paragraphs while respecting max chunk size.
    Useful for preserving semantic structure.
    """

    if not text or not text.strip():
        return []

    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]

    chunks: List[str] = []
    current_chunk = ""

    for para in paragraphs:
        if len(current_chunk) + len(para) <= max_chunk_size:
            current_chunk += para + "\n"
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = para + "\n"

    if current_chunk.strip():
        chunks.append(current_chunk.strip())

    return chunks