from sqlalchemy import Column, ForeignKey, Integer, String, Text, DateTime
from sqlalchemy.sql import func

from app.database import Base


class QuizQuestion(Base):
    """
    Stores quiz questions generated from uploaded study materials.
    """

    __tablename__ = "quiz_questions"

    id = Column(Integer, primary_key=True, index=True)

    # Reference to uploaded study material
    material_id = Column(
        Integer,
        ForeignKey("study_materials.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Question text
    question = Column(Text, nullable=False)

    # JSON-encoded list of answer options
    options = Column(Text, nullable=True)

    # Correct answer
    answer = Column(Text, nullable=False)

    # Explanation for the correct answer
    explanation = Column(Text, nullable=True)

    # Difficulty level: easy, medium, hard
    difficulty = Column(String(50), nullable=False, default="medium")

    # Audit timestamps
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    def __repr__(self) -> str:
        return (
            f"<QuizQuestion(id={self.id}, "
            f"material_id={self.material_id}, "
            f"difficulty='{self.difficulty}')>"
        )