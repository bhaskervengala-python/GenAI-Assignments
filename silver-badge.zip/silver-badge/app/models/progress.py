from sqlalchemy import Column, DateTime, Float, Integer, String
from sqlalchemy.sql import func

from app.database import Base


class Progress(Base):
    """
    Tracks a student's mastery level for each concept and schedules
    future reviews using spaced repetition.
    """

    __tablename__ = "progress"

    id = Column(Integer, primary_key=True, index=True)

    # Concept name (e.g., "Photosynthesis")
    concept = Column(String(255), unique=True, nullable=False, index=True)

    # Mastery score between 0.0 and 1.0
    mastery = Column(Float, nullable=False, default=0.0)

    # Number of days until next review
    review_interval = Column(Integer, nullable=False, default=1)

    # Scheduled date/time for next review
    next_review = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Audit timestamps
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    def __repr__(self) -> str:
        return (
            f"<Progress(id={self.id}, concept='{self.concept}', "
            f"mastery={self.mastery:.2f}, "
            f"review_interval={self.review_interval})>"
        )