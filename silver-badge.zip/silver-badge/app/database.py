
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings

# -------------------------------------------------------------------
# Database Engine
# -------------------------------------------------------------------

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False}
    if settings.DATABASE_URL.startswith("sqlite")
    else {},
    pool_pre_ping=True,
)

# -------------------------------------------------------------------
# Session Local
# -------------------------------------------------------------------

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

# -------------------------------------------------------------------
# Base Class for ORM Models
# -------------------------------------------------------------------

Base = declarative_base()


# -------------------------------------------------------------------
# Dependency: DB Session
# -------------------------------------------------------------------

def get_db():
    """
    FastAPI dependency that provides a DB session.
    Ensures proper closing of session after request.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()