from pathlib import Path
from typing import Optional

from pypdf import PdfReader
from docx import Document


class ContentExtractor:
    """
    Extracts raw text content from supported file types:
    - PDF
    - DOCX
    - TXT
    """

    def extract(self, file_path: str) -> str:
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        suffix = path.suffix.lower()

        if suffix == ".txt":
            return self._extract_txt(path)

        if suffix == ".pdf":
            return self._extract_pdf(path)

        if suffix == ".docx":
            return self._extract_docx(path)

        raise ValueError(f"Unsupported file type: {suffix}")

    def _extract_txt(self, path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            raise RuntimeError(f"Failed to read TXT file: {str(e)}") from e

    def _extract_pdf(self, path: Path) -> str:
        try:
            reader = PdfReader(str(path))
            text_parts = []

            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)

            return "\n".join(text_parts).strip()

        except Exception as e:
            raise RuntimeError(f"Failed to extract PDF content: {str(e)}") from e

    def _extract_docx(self, path: Path) -> str:
        try:
            doc = Document(str(path))
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            return "\n".join(paragraphs).strip()

        except Exception as e:
            raise RuntimeError(f"Failed to extract DOCX content: {str(e)}") from e    