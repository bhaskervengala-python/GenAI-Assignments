import re
from collections import Counter
from typing import List, Set


class ConceptAnalyzer:
    """
    Extracts key concepts/keywords from study material text.
    This is a lightweight heuristic-based approach (can be replaced with LLM later).
    """

    def __init__(self):
        # Basic stopwords (can be expanded or replaced with NLTK later)
        self.stopwords: Set[str] = {
            "the", "is", "in", "at", "of", "on", "and", "a", "an",
            "to", "for", "with", "that", "this", "it", "as", "are",
            "was", "were", "be", "by", "from", "or", "which", "but",
            "about", "into", "over", "after", "before", "between",
        }

    def clean_text(self, text: str) -> List[str]:
        """
        Tokenizes and cleans text into words.
        """
        words = re.findall(r"\b[a-zA-Z]{3,}\b", text.lower())
        return [w for w in words if w not in self.stopwords]

    def extract_key_concepts(self, text: str, top_k: int = 15) -> List[str]:
        """
        Extracts most common meaningful words as concepts.
        """
        if not text or not text.strip():
            return []

        words = self.clean_text(text)

        if not words:
            return []

        freq = Counter(words)

        # Sort by frequency (descending)
        common = freq.most_common(top_k)

        concepts = [word for word, _ in common]

        return concepts

    def extract_phrases(self, text: str, max_phrases: int = 10) -> List[str]:
        """
        Optional: extract simple bigram phrases for better concept quality.
        """
        words = self.clean_text(text)

        if len(words) < 2:
            return []

        bigrams = zip(words, words[1:])
        phrases = [" ".join(bg) for bg in bigrams]

        freq = Counter(phrases)

        return [p for p, _ in freq.most_common(max_phrases)]