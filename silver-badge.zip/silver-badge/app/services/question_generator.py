import json
from typing import List, Dict, Any

from openai import OpenAI

from app.config import settings
from app.utils.text_chunker import chunk_text


class QuestionGenerator:
    """
    Generates quiz questions from study material using an LLM.
    """

    def __init__(self):
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def generate_questions(self, content: str, num_questions: int = 5) -> List[Dict[str, Any]]:
        """
        Generate MCQ-style questions from study content.
        """

        if not content or not content.strip():
            return []

        # Break content into chunks (helps avoid token overflow)
        chunks = chunk_text(content, chunk_size=3000, overlap=200)

        # Use only first few chunks for simplicity (can be improved later)
        selected_content = "\n\n".join(chunks[:3])

        prompt = self._build_prompt(selected_content, num_questions)

        try:
            response = self.client.responses.create(
                model=settings.MODEL_NAME,
                input=prompt,
            )

            raw_text = (response.output_text or "").strip()

            return self._safe_parse_json(raw_text)

        except Exception as e:
            raise RuntimeError(f"Question generation failed: {str(e)}") from e

    def _build_prompt(self, content: str, num_questions: int) -> str:
        return f"""
You are an expert teacher.

Generate {num_questions} multiple-choice questions (MCQs) from the given study material.

IMPORTANT RULES:
- Return ONLY valid JSON
- Do NOT include explanations outside JSON
- Each question must have 4 options
- Ensure one correct answer per question

FORMAT:
[
  {{
    "question": "...",
    "options": ["A", "B", "C", "D"],
    "answer": "A",
    "explanation": "...",
    "difficulty": "easy|medium|hard"
  }}
]

STUDY MATERIAL:
{content}
"""

    def _safe_parse_json(self, text: str) -> List[Dict[str, Any]]:
        """
        Safely parse LLM output into JSON.
        Handles markdown-wrapped or malformed responses.
        """

        if not text:
            return []

        # Remove markdown code fences if present
        cleaned = text.strip()
        cleaned = cleaned.replace("```json", "").replace("```", "").strip()

        try:
            data = json.loads(cleaned)

            if isinstance(data, list):
                return data

            return []

        except json.JSONDecodeError:
            # fallback: try to extract JSON block
            start = cleaned.find("[")
            end = cleaned.rfind("]")

            if start != -1 and end != -1:
                try:
                    return json.loads(cleaned[start : end + 1])
                except Exception:
                    return []

            return []