from datetime import datetime
from typing import List, Dict, Any

from app.models.progress import Progress


class ScheduleService:
    """
    Builds a spaced-repetition based study schedule from progress data.
    """

    def build_schedule(self, progress_items: List[Progress]) -> List[Dict[str, Any]]:
        """
        Convert progress records into a prioritized study schedule.
        """

        now = datetime.utcnow()
        schedule: List[Dict[str, Any]] = []

        for item in progress_items:
            if not item:
                continue

            # Only include items due for review
            if item.next_review and item.next_review > now:
                continue

            mastery = float(item.mastery or 0.0)

            # Priority: lower mastery => higher priority
            priority = self._calculate_priority(mastery, item.review_interval)

            schedule.append(
                {
                    "concept": item.concept,
                    "mastery": mastery,
                    "review_interval": item.review_interval,
                    "priority": priority,
                    "next_review": item.next_review,
                }
            )

        # Sort by priority (descending)
        schedule.sort(key=lambda x: x["priority"], reverse=True)

        return schedule

    def _calculate_priority(self, mastery: float, interval: int) -> float:
        """
        Higher priority for:
        - Low mastery
        - Short intervals (needs repetition)
        """

        mastery_factor = 1.0 - mastery
        interval_factor = 1.0 / max(interval, 1)

        return round((mastery_factor * 0.7) + (interval_factor * 0.3), 4)

    def due_today(self, progress_items: List[Progress]) -> List[Progress]:
        """
        Returns items due for review today.
        """

        now = datetime.utcnow()

        return [
            item
            for item in progress_items
            if item.next_review and item.next_review <= now
        ]

    def summary_stats(self, progress_items: List[Progress]) -> Dict[str, Any]:
        """
        Generate quick analytics about learning progress.
        """

        if not progress_items:
            return {
                "total_concepts": 0,
                "avg_mastery": 0.0,
                "strong": 0,
                "weak": 0,
            }

        total = len(progress_items)
        avg_mastery = sum(p.mastery for p in progress_items) / total

        strong = len([p for p in progress_items if p.mastery >= 0.7])
        weak = len([p for p in progress_items if p.mastery < 0.3])

        return {
            "total_concepts": total,
            "avg_mastery": round(avg_mastery, 3),
            "strong": strong,
            "weak": weak,
        }