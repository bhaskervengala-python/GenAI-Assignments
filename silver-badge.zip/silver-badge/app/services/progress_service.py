from datetime import datetime, timedelta


class ProgressService:
    """
    Handles learning progress updates using a simple spaced repetition logic.
    """

    def update_mastery(self, current_mastery: float, correct: bool) -> float:
        """
        Adjust mastery score based on quiz performance.
        """
        if correct:
            return min(1.0, current_mastery + 0.1)

        return max(0.0, current_mastery - 0.05)

    def next_interval(self, current_interval: int, correct: bool) -> int:
        """
        Adjust review interval (spaced repetition).
        """
        if correct:
            # exponential increase when correct
            return min(current_interval * 2, 64)

        # reset when incorrect
        return 1

    def next_review_date(self, interval_days: int) -> datetime:
        """
        Compute next review date based on interval.
        """
        return datetime.utcnow() + timedelta(days=interval_days)

    def calculate_stability(self, mastery: float, interval: int) -> float:
        """
        Optional metric: how stable a concept is.
        Higher mastery + longer interval = higher stability.
        """
        return round(min(1.0, mastery * (1 + (interval / 32))), 3)

    def recommendation_strength(self, mastery: float) -> str:
        """
        Convert mastery score into a human-readable label.
        """
        if mastery < 0.3:
            return "weak"
        elif mastery < 0.7:
            return "moderate"
        return "strong"