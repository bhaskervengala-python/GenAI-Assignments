from openai import OpenAI

from app.config import settings


class ExplanationService:
    """
    Generates personalized explanations for concepts using an LLM,
    adapted to different learning styles.
    """

    def __init__(self):
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def explain(self, concept: str, learning_style: str = "visual") -> str:
        """
        Generate an explanation tailored to a learning style.

        learning_style: visual | auditory | kinesthetic
        """

        prompt = self._build_prompt(concept, learning_style)

        try:
            response = self.client.responses.create(
                model=settings.MODEL_NAME,
                input=prompt,
            )

            return (response.output_text or "").strip()

        except Exception as e:
            raise RuntimeError(f"LLM explanation failed: {str(e)}") from e

    def _build_prompt(self, concept: str, learning_style: str) -> str:
        """
        Builds a structured prompt for better LLM output quality.
        """

        base_instruction = f"""
You are an expert tutor.

Explain the concept: "{concept}"

Make the explanation clear, simple, and structured.
"""

        if learning_style == "visual":
            style_instruction = """
Learning style: VISUAL
- Use analogies
- Use mental imagery
- Describe diagrams in words
"""
        elif learning_style == "auditory":
            style_instruction = """
Learning style: AUDITORY
- Explain as if speaking aloud
- Use conversational tone
- Use repetition for clarity
"""
        elif learning_style == "kinesthetic":
            style_instruction = """
Learning style: KINESTHETIC
- Use real-world examples
- Focus on "learning by doing"
- Include step-by-step actions
"""
        else:
            style_instruction = """
Learning style: GENERAL
- Use simple explanations
"""

        return f"""{base_instruction}

{style_instruction}

Keep it concise but deeply understandable.
If helpful, include examples.
"""