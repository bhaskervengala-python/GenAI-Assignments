from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.study_material import StudyMaterial
from app.services.question_generator import QuestionGenerator

router = APIRouter()
question_generator = QuestionGenerator()


# -------------------------------------------------------------------
# Response Schemas
# -------------------------------------------------------------------

class QuizQuestionResponse(BaseModel):
    question: str
    options: list[str] = Field(default_factory=list)
    answer: str
    explanation: Optional[str] = None
    difficulty: str = "medium"


class QuizResponse(BaseModel):
    material_id: int
    title: str
    num_questions: int
    questions: list[QuizQuestionResponse]


# -------------------------------------------------------------------
# API Endpoints
# -------------------------------------------------------------------

@router.get(
    "/quiz/{material_id}",
    response_model=QuizResponse,
    summary="Generate quiz questions from study material",
)
def generate_quiz(
    material_id: int,
    num_questions: int = Query(
        5,
        ge=1,
        le=20,
        description="Number of quiz questions to generate",
    ),
    db: Session = Depends(get_db),
):
    """
    Generate AI-powered quiz questions based on uploaded study material.

    Example:
    GET /api/quiz/1?num_questions=10
    """

    material = (
        db.query(StudyMaterial)
        .filter(StudyMaterial.id == material_id)
        .first()
    )

    if not material:
        raise HTTPException(
            status_code=404,
            detail=f"Study material with id {material_id} not found.",
        )

    try:
        questions_data = question_generator.generate_questions(
            content=material.content,
            num_questions=num_questions,
        )

        if not isinstance(questions_data, list):
            raise ValueError("Generated quiz response must be a list.")

        questions: list[QuizQuestionResponse] = []

        for item in questions_data:
            if not isinstance(item, dict):
                continue

            questions.append(
                QuizQuestionResponse(
                    question=item.get("question", ""),
                    options=item.get("options", []),
                    answer=item.get("answer", ""),
                    explanation=item.get("explanation"),
                    difficulty=item.get("difficulty", "medium"),
                )
            )

        if not questions:
            raise ValueError("No valid quiz questions were generated.")

        return QuizResponse(
            material_id=material.id,
            title=material.title,
            num_questions=len(questions),
            questions=questions,
        )

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate quiz: {str(exc)}",
        ) from exc