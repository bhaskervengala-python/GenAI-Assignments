from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.progress import Progress
from app.services.progress_service import ProgressService

router = APIRouter()
progress_service = ProgressService()


# -------------------------------------------------------------------
# Request / Response Schemas
# -------------------------------------------------------------------

class ProgressCreateRequest(BaseModel):
    concept: str = Field(..., description="Concept name to track")
    mastery: float = Field(0.0, ge=0.0, le=1.0)
    review_interval: int = Field(1, ge=1)


class ProgressUpdateRequest(BaseModel):
    correct: bool = Field(..., description="Whether the student answered correctly")


class ProgressResponse(BaseModel):
    id: int
    concept: str
    mastery: float
    review_interval: int
    next_review: datetime

    class Config:
        from_attributes = True


# -------------------------------------------------------------------
# Create Progress Record
# -------------------------------------------------------------------

@router.post("/progress", response_model=ProgressResponse)
def create_progress(
    payload: ProgressCreateRequest,
    db: Session = Depends(get_db),
):
    existing = (
        db.query(Progress)
        .filter(Progress.concept == payload.concept)
        .first()
    )

    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Progress already exists for concept '{payload.concept}'."
        )

    progress = Progress(
        concept=payload.concept,
        mastery=payload.mastery,
        review_interval=payload.review_interval,
        next_review=progress_service.next_review_date(
            payload.review_interval
        ),
    )

    db.add(progress)
    db.commit()
    db.refresh(progress)

    return progress


# -------------------------------------------------------------------
# Get All Progress Records
# -------------------------------------------------------------------

@router.get("/progress", response_model=list[ProgressResponse])
def get_all_progress(db: Session = Depends(get_db)):
    return db.query(Progress).order_by(Progress.next_review.asc()).all()


# -------------------------------------------------------------------
# Get Progress by Concept
# -------------------------------------------------------------------

@router.get("/progress/{concept}", response_model=ProgressResponse)
def get_progress(concept: str, db: Session = Depends(get_db)):
    progress = (
        db.query(Progress)
        .filter(Progress.concept == concept)
        .first()
    )

    if not progress:
        raise HTTPException(
            status_code=404,
            detail=f"Concept '{concept}' not found."
        )

    return progress


# -------------------------------------------------------------------
# Update Progress After Quiz Answer
# -------------------------------------------------------------------

@router.put("/progress/{concept}", response_model=ProgressResponse)
def update_progress(
    concept: str,
    payload: ProgressUpdateRequest,
    db: Session = Depends(get_db),
):
    progress = (
        db.query(Progress)
        .filter(Progress.concept == concept)
        .first()
    )

    if not progress:
        raise HTTPException(
            status_code=404,
            detail=f"Concept '{concept}' not found."
        )

    # Update mastery score
    progress.mastery = progress_service.update_mastery(
        progress.mastery,
        payload.correct,
    )

    # Update review interval
    progress.review_interval = progress_service.next_interval(
        progress.review_interval,
        payload.correct,
    )

    # Update next review date
    progress.next_review = progress_service.next_review_date(
        progress.review_interval
    )

    db.commit()
    db.refresh(progress)

    return progress


# -------------------------------------------------------------------
# Delete Progress Record
# -------------------------------------------------------------------

@router.delete("/progress/{concept}")
def delete_progress(concept: str, db: Session = Depends(get_db)):
    progress = (
        db.query(Progress)
        .filter(Progress.concept == concept)
        .first()
    )

    if not progress:
        raise HTTPException(
            status_code=404,
            detail=f"Concept '{concept}' not found."
        )

    db.delete(progress)
    db.commit()

    return {
        "message": f"Progress for concept '{concept}' deleted successfully."
    }


# -------------------------------------------------------------------
# Get Due Concepts for Review
# -------------------------------------------------------------------

@router.get("/progress/due/review")
def due_for_review(db: Session = Depends(get_db)):
    now = datetime.utcnow()

    due_items = (
        db.query(Progress)
        .filter(Progress.next_review <= now)
        .order_by(Progress.mastery.asc())
        .all()
    )

    return {
        "count": len(due_items),
        "items": due_items,
    }