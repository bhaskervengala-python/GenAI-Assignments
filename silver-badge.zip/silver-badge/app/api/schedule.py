from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.progress import Progress
from app.services.schedule_service import ScheduleService

router = APIRouter()
schedule_service = ScheduleService()


# -------------------------------------------------------------------
# Response Schemas
# -------------------------------------------------------------------

class ScheduleItemResponse(BaseModel):
    concept: str
    mastery: float
    priority: float


class ScheduleResponse(BaseModel):
    generated_at: datetime
    total_due: int
    items: list[ScheduleItemResponse]


# -------------------------------------------------------------------
# API Endpoints
# -------------------------------------------------------------------

@router.get(
    "/schedule",
    response_model=ScheduleResponse,
    summary="Generate personalized study schedule",
)
def get_study_schedule(db: Session = Depends(get_db)):
    """
    Returns concepts that are due for review based on spaced repetition.

    Concepts with lower mastery are given higher priority.
    """

    progress_items = db.query(Progress).all()

    schedule_items = schedule_service.build_schedule(progress_items)

    items = [
        ScheduleItemResponse(
            concept=item["concept"],
            mastery=item["mastery"],
            priority=item["priority"],
        )
        for item in schedule_items
    ]

    return ScheduleResponse(
        generated_at=datetime.utcnow(),
        total_due=len(items),
        items=items,
    )


@router.get(
    "/schedule/due-today",
    response_model=ScheduleResponse,
    summary="Get concepts due for review today",
)
def get_due_today(db: Session = Depends(get_db)):
    """
    Alias endpoint for retrieving today's due review items.
    """

    progress_items = db.query(Progress).all()

    schedule_items = schedule_service.build_schedule(progress_items)

    items = [
        ScheduleItemResponse(
            concept=item["concept"],
            mastery=item["mastery"],
            priority=item["priority"],
        )
        for item in schedule_items
    ]

    return ScheduleResponse(
        generated_at=datetime.utcnow(),
        total_due=len(items),
        items=items,
    )