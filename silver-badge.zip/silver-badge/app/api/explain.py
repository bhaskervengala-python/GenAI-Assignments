from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.services.explanation_service import ExplanationService

router = APIRouter()
explanation_service = ExplanationService()


# -------------------------------------------------------------------
# Response Schemas
# -------------------------------------------------------------------

class ExplanationResponse(BaseModel):
    concept: str
    learning_style: str
    explanation: str


class LearningStyleOptions(BaseModel):
    supported_learning_styles: list[str]


# -------------------------------------------------------------------
# Supported Learning Styles
# -------------------------------------------------------------------

SUPPORTED_LEARNING_STYLES = {
    "visual",
    "auditory",
    "kinesthetic",
}


# -------------------------------------------------------------------
# API Endpoints
# -------------------------------------------------------------------

@router.get(
    "/explain",
    response_model=ExplanationResponse,
    summary="Explain a concept",
    description=(
        "Generate an AI explanation of a concept tailored to the "
        "selected learning style."
    ),
)
def explain_concept(
    concept: str = Query(
        ...,
        min_length=2,
        description="Concept to explain (e.g., photosynthesis)"
    ),
    learning_style: str = Query(
        "visual",
        description="Learning style: visual, auditory, or kinesthetic"
    ),
):
    """
    Example:
    GET /api/explain?concept=Newton's Laws&learning_style=visual
    """

    learning_style = learning_style.lower().strip()

    if learning_style not in SUPPORTED_LEARNING_STYLES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported learning style '{learning_style}'. "
                f"Supported styles: {', '.join(sorted(SUPPORTED_LEARNING_STYLES))}"
            ),
        )

    try:
        explanation = explanation_service.explain(
            concept=concept,
            learning_style=learning_style,
        )

        return ExplanationResponse(
            concept=concept,
            learning_style=learning_style,
            explanation=explanation,
        )

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate explanation: {str(exc)}"
        ) from exc


@router.get(
    "/explain/styles",
    response_model=LearningStyleOptions,
    summary="List supported learning styles",
)
def get_learning_styles():
    """
    Returns all supported learning styles.
    """
    return LearningStyleOptions(
        supported_learning_styles=sorted(SUPPORTED_LEARNING_STYLES)
    )