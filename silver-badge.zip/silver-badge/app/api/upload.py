import os
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.study_material import StudyMaterial
from app.services.content_extractor import ContentExtractor
from app.services.concept_analyzer import ConceptAnalyzer

router = APIRouter()

content_extractor = ContentExtractor()
concept_analyzer = ConceptAnalyzer()

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}
MAX_FILE_SIZE = 25 * 1024 * 1024  # 25 MB


# -------------------------------------------------------------------
# Response Schema
# -------------------------------------------------------------------

class UploadResponse(BaseModel):
    material_id: int
    title: str
    file_path: str
    characters: int
    concepts: list[str]


# -------------------------------------------------------------------
# Helper Functions
# -------------------------------------------------------------------

def validate_file(file: UploadFile):
    extension = Path(file.filename).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type '{extension}'. "
                f"Allowed types: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
            ),
        )


# -------------------------------------------------------------------
# API Endpoints
# -------------------------------------------------------------------

@router.post(
    "/upload",
    response_model=UploadResponse,
    summary="Upload study material",
)
async def upload_material(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Upload a PDF, DOCX, or TXT file and extract its contents.
    """

    if not file.filename:
        raise HTTPException(
            status_code=400,
            detail="Filename is missing.",
        )

    validate_file(file)

    # Save uploaded file
    file_path = UPLOAD_DIR / file.filename

    content_bytes = await file.read()

    if len(content_bytes) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File exceeds maximum size of {MAX_FILE_SIZE // (1024*1024)} MB.",
        )

    with open(file_path, "wb") as f:
        f.write(content_bytes)

    # Extract text
    try:
        extracted_content = content_extractor.extract(str(file_path))
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to extract content: {str(exc)}",
        ) from exc

    if not extracted_content.strip():
        raise HTTPException(
            status_code=400,
            detail="No readable text found in the uploaded file.",
        )

    # Extract concepts
    concepts = concept_analyzer.extract_key_concepts(
        extracted_content,
        top_k=15,
    )

    # Store in database
    material = StudyMaterial(
        title=file.filename,
        file_path=str(file_path),
        content=extracted_content,
    )

    db.add(material)
    db.commit()
    db.refresh(material)

    return UploadResponse(
        material_id=material.id,
        title=material.title,
        file_path=material.file_path,
        characters=len(extracted_content),
        concepts=concepts,
    )


@router.get(
    "/materials",
    summary="List uploaded study materials",
)
def list_materials(db: Session = Depends(get_db)):
    materials = db.query(StudyMaterial).all()

    return [
        {
            "id": material.id,
            "title": material.title,
            "created_at": material.created_at,
        }
        for material in materials
    ]


@router.get(
    "/materials/{material_id}",
    summary="Get study material details",
)
def get_material(material_id: int, db: Session = Depends(get_db)):
    material = (
        db.query(StudyMaterial)
        .filter(StudyMaterial.id == material_id)
        .first()
    )

    if not material:
        raise HTTPException(
            status_code=404,
            detail="Study material not found.",
        )

    return {
        "id": material.id,
        "title": material.title,
        "file_path": material.file_path,
        "content_preview": material.content[:1000],
        "characters": len(material.content),
        "created_at": material.created_at,
    }


@router.delete(
    "/materials/{material_id}",
    summary="Delete study material",
)
def delete_material(material_id: int, db: Session = Depends(get_db)):
    material = (
        db.query(StudyMaterial)
        .filter(StudyMaterial.id == material_id)
        .first()
    )

    if not material:
        raise HTTPException(
            status_code=404,
            detail="Study material not found.",
        )

    # Remove physical file if it exists
    if os.path.exists(material.file_path):
        os.remove(material.file_path)

    db.delete(material)
    db.commit()

    return {
        "message": f"Study material '{material.title}' deleted successfully."
    }